function changecolor(color) {
    document.body.style.backgroundColor = color; // Fixed function to use dynamic color
}

function resetcolor() {
    document.body.style.backgroundColor = "lightblue";
}